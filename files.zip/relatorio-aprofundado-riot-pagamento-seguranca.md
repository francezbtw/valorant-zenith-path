# Relatório Aprofundado — Integração Riot, Pagamento, RLS e Próximos Passos

> Complementa o relatório anterior (`relatorio-analise-valorant-zenith-path.md`). Aqui: (1) o que foi **implementado agora** (integração Valorant), (2) revisão de segurança **em profundidade** do RLS, (3) proposta de arquitetura de pagamento, (4) recomendações de refatoração e testes.

---

## 1. O que foi implementado: Área de Membros ↔ Valorant

### 1.1 Por que não é uma sincronização automática de rank via Riot API

Antes de qualquer código, um ponto importante que muda a viabilidade do que foi pedido: consultei a documentação atual do **Riot Developer Portal** e a política de acesso à API de VALORANT hoje é:

- Qualquer app que acesse **dados pessoais de jogador** (elo, partidas, conta específica) precisa do fluxo **RSO (Riot Sign On)** + uma **Production API Key aprovada**.
- A documentação oficial afirma explicitamente: *"Note: Personal Key Applications are currently not supported"* para esse fluxo — ou seja, hoje a Riot **não está aceitando** solicitações de chave em nível pessoal/pequeno projeto para isso, e a aprovação de produção passa por avaliação de marca/produto pela própria Riot.

Na prática, isso significa que uma sincronização automática e contínua de "elo atual" puxando direto da conta Riot do aluno **depende de uma aprovação da Riot que está fora do nosso controle** — não é uma questão de código, é uma decisão de negócio/parceria com a Riot.

### 1.2 O que construí, então (e por quê é a solução certa hoje)

Implementei uma arquitetura **honesta e funcional imediatamente**, mas já preparada para ativar a sincronização oficial se/quando uma chave de produção for aprovada:

1. **Vínculo de conta** (`/app/perfil` → card "Conta Valorant"): o aluno informa `Nome#TAG` + região.
2. **Link automático para o Tracker.gg** — gerado a partir do Riot ID, sem depender de nenhuma chave de API (funciona 100% hoje, é o mesmo mecanismo que outros produtos de coaching usam para mostrar o perfil público de partidas).
3. **Tentativa best-effort de verificação via Riot API** (`Account-V1`, que historicamente é menos restrita que os endpoints de elo/partidas): se você conseguir uma `RIOT_API_KEY` (mesmo que só de desenvolvimento) e configurá-la nas secrets do Lovable Cloud, o sistema já tenta confirmar que o Riot ID existe e marca a conta como "Verificada". Sem a chave, o app não trava — simplesmente não mostra o selo de verificado.
4. **Evolução de elo real** (`/app/progresso` → card "Evolução de elo"): o aluno faz check-ins manuais do elo atual (Ferro → Radiante) + RR, e isso alimenta um **gráfico de linha (recharts)** mostrando a curva de evolução ao longo do tempo — que é, na prática, o "acompanhar a evolução" que você pediu, funcionando sem qualquer dependência da Riot.

### 1.3 Arquivos criados/alterados

| Arquivo | O que faz |
|---|---|
| `supabase/migrations/20260725010000_riot_valorant_tracking.sql` | Tabelas `riot_accounts` e `riot_rank_snapshots`, com RLS **e privilégios em nível de coluna** (ver §2.4) |
| `src/lib/riot.ts` | Constantes puras: regiões, tabela de elos (Ferro→Radiante) em PT-BR, gerador de link do Tracker.gg |
| `src/integrations/riot/client.server.ts` | Cliente **server-only** para a Riot API (nunca vai ao bundle do cliente); lê `RIOT_API_KEY` do ambiente |
| `src/lib/riot-actions.functions.ts` | Server functions `linkRiotAccount` e `addRankSnapshot` (TanStack Start), autenticadas via `requireSupabaseAuth` |
| `src/hooks/use-riot.ts` | Hooks React Query: `useRiotAccount`, `useRankHistory`, `useLinkRiotAccount`, `useAddRankSnapshot` |
| `src/integrations/supabase/types.ts` | Tipos das novas tabelas adicionados manualmente, seguindo o padrão do arquivo (normalmente gerado pelo Supabase CLI) |
| `src/routes/_authenticated/app.perfil.tsx` | Novo card "Conta Valorant" (vincular Riot ID, ver status de verificação, link Tracker.gg) |
| `src/routes/_authenticated/app.progresso.tsx` | Novo card "Evolução de elo" (gráfico + formulário de check-in) |
| `.env.example` | Novo — documenta todas as variáveis, incluindo `RIOT_API_KEY` (opcional) |
| `.gitignore` | **Corrigido**: `.env` não estava ignorado (ver §2.5) |

### 1.4 Segurança da nova feature (resumo — detalhe completo no §2.4)

- Um aluno **não consegue forjar** seu próprio "elo verificado": as colunas `puuid`/`verified`/`last_verified_at` só podem ser escritas pelo `service_role` (a chamada do cliente só tem permissão de coluna para `riot_game_name`/`riot_tag_line`/`region`).
- Os check-ins de elo (`riot_rank_snapshots`) são autodeclarados pelo próprio aluno — mesmo modelo de confiança que `lesson_progress` já usa hoje (o aluno também "autodeclara" que assistiu a aula). Não há dado de terceiro em jogo.

### 1.5 O que falta para você rodar isso

1. **Rodar a migration** no Supabase (via Lovable Cloud ou `supabase db push`, dependendo de como vocês aplicam migrations hoje).
2. **(Opcional)** Se quiser tentar o selo de verificação: registrar um app em `developer.riotgames.com`, gerar uma chave de desenvolvimento (válida por 24h, só para teste) e configurá-la como `RIOT_API_KEY` nas secrets do ambiente (nunca no `.env` versionado). Sem isso, a feature funciona igual, só sem o selo verde.
3. ⚠️ **Não pude rodar `npm install` nem `npm run build`/`tsc` neste ambiente** (sem acesso de rede no sandbox onde fiz a análise). O código segue fielmente os padrões já existentes no projeto (mesmo estilo de hooks, mesma convenção de server functions sugerida pelos comentários do próprio repo), mas recomendo fortemente rodar `npm install && npm run build` (ou `bun run build`) localmente/no Lovable antes de considerar isso pronto para produção, para pegar qualquer erro de tipos que eu não consiga ver sem o compilador.

---

## 2. Revisão de Segurança do RLS — em profundidade

Fiz uma segunda passada, tabela por tabela, procurando especificamente por: (a) escalonamento de privilégio, (b) *insecure direct object reference*, (c) dados que vazam entre alunos, (d) *race conditions* em funções.

| Tabela | Cenário testado mentalmente | Resultado |
|---|---|---|
| `profiles` | Usuário A tenta `select`/`update` no `id` do usuário B | **Bloqueado** — `using (auth.uid() = id)` em todas as policies |
| `enrollments` | Usuário tenta fazer `insert`/`update` para se autoconceder um plano superior | **Bloqueado** — só existe policy de `select`; não há `grant insert/update` para `authenticated`, só para `service_role` |
| `modules` | Qualquer autenticado lê todos os módulos, mesmo os que não tem acesso | **Esperado e correto** — só o *conteúdo* (`lessons`) é restrito; ver o nome/descrição do módulo "Mentoria Elite" sem ter o plano é o comportamento de vitrine (mostra o que existe para incentivar upgrade) |
| `lessons` | Usuário sem enrollment (nenhuma linha em `enrollments`) tenta ler aula do módulo básico | `current_plan()` retorna `null` → `plan_rank(null)` é `null` → `coalesce(null >= x, false)` → **nega corretamente**, mesmo aula do tier básico |
| `lessons` | Usuário com plano expirado (`expires_at < now()`) | `current_plan()` filtra `expires_at is null or expires_at > now()` → **acesso revogado automaticamente** assim que expira, sem precisar de job/cron |
| `lesson_progress` | Usuário tenta gravar progresso em `lesson_id` de outro usuário | A PK é `(user_id, lesson_id)` e a policy usa `using/with check (auth.uid() = user_id)` → **bloqueado**; ele só pode gravar linhas com o próprio `user_id` |
| `announcements` | Usuário do plano Básico tenta ler aviso `min_tier = 'mentoria'` | **Bloqueado** pela mesma função `has_plan_access` |
| Funções (`current_plan`, `has_plan_access`, `plan_rank`) | Tentativa de *search_path hijacking* (criar uma tabela/função maliciosa em outro schema que a function acabe chamando) | **Mitigado** — todas têm `set search_path = public` explícito, prática correta que evita a classe de vulnerabilidade mais comum em funções `SECURITY DEFINER`/`INVOKER` do Postgres |
| `current_plan`/`has_plan_access` | Por que migraram de `security definer` para `security invoker`? | Com `definer`, a função roda com os privilégios de quem **criou** a função (geralmente um role com mais acesso), o que é uma superfície de risco desnecessária aqui, já que a função só faz `select` em uma tabela que o próprio usuário já tem policy de leitura (`enrollments`). Trocar para `invoker` é o princípio do menor privilégio aplicado corretamente — **boa decisão** de quem revisou o schema depois |
| `handle_new_user` (trigger) | Continua `security definer` — é necessário? | **Sim, correto**: o trigger roda em resposta a um `insert` em `auth.users` (schema que o usuário comum não teria acesso de escrita em `profiles` "em nome de"), então precisa rodar com privilégio elevado para criar a linha correspondente em `profiles`. Está com `set search_path` fixo, então o risco de hijacking está coberto. |

### 2.1 Pontos que valem atenção (não são bugs, são decisões a validar com o negócio)

1. **`enrollments` tem `unique(user_id)`** — um aluno só pode ter **um** plano ativo por vez. Se no futuro vocês quiserem vender upgrades/downgrades com histórico (ex.: "foi Básico por 3 meses, depois virou Mentoria"), o schema atual sobrescreve em vez de manter histórico. Recomendo, se for integrar pagamento (§3), avaliar se querem manter histórico de mudanças de plano (tabela `plan_history` separada) ou se o `enrollments` atual (estado corrente) é suficiente — geralmente é, mas vale a decisão consciente.
2. **`modules`/`lessons` sem policy de `insert`/`update`/`delete` para `authenticated`** — correto (conteúdo só é editado via admin/service_role), só confirme que a equipe de conteúdo edita via SQL Editor do Supabase ou um painel admin futuro, nunca client-side.
3. **Nenhuma tabela tem *soft delete*** — deletar um módulo/aula (`on delete cascade`) apaga o progresso associado dos alunos permanentemente. Se decidirem "descontinuar" um módulo no futuro, prefiram um campo `archived boolean` a um `delete` físico, para não perder o histórico de progresso dos alunos.

### 2.2 Nenhuma vulnerabilidade crítica encontrada

Não encontrei nenhum caminho para: leitura de dados de outro aluno, escalonamento para um plano não pago, ou bypass de RLS a partir do client. O desenho é sólido.

### 2.3 Sugestão de teste automatizado de RLS

O jeito mais direto de manter essa garantia ao longo do tempo é um teste de RLS que rode a cada mudança de schema (pgTAP ou um script simples com `supabase-js` usando dois usuários de teste, tentando acessar dado um do outro e esperando erro). Ver §4.2.

### 2.4 Detalhe do RLS + privilégio de coluna nas novas tabelas (Riot)

Isso é uma técnica que o schema original **não usava ainda** (RLS é por linha, não por coluna), então documento aqui o padrão que apliquei:

```sql
grant select on public.riot_accounts to authenticated;
grant insert (user_id, riot_game_name, riot_tag_line, region) on public.riot_accounts to authenticated;
grant update (riot_game_name, riot_tag_line, region) on public.riot_accounts to authenticated;
grant all on public.riot_accounts to service_role;
```

Mesmo que a policy de RLS permita `update` na própria linha, o Postgres **também** checa privilégio de coluna — então mesmo que alguém manipule o payload da requisição para tentar setar `verified: true` diretamente via `supabase.from('riot_accounts').update(...)`, o Postgres rejeita porque o role `authenticated` não tem `UPDATE` naquela coluna especificamente. Só a server function (que usa `supabaseAdmin`/`service_role`) consegue gravar esses campos. Vale considerar aplicar esse mesmo padrão em outras tabelas no futuro sempre que houver "campos de usuário" misturados com "campos calculados/de confiança" na mesma tabela.

### 2.5 Achado: `.env` não estava no `.gitignore`

O `.gitignore` do repositório **não incluía `.env`**, ou seja, o arquivo com `SUPABASE_URL`/`SUPABASE_PUBLISHABLE_KEY` (e, se vocês tivessem adicionado, futuramente a `RIOT_API_KEY`) estava sujeito a ser commitado no Git. Corrigi isso:
- Adicionei `.env`, `.env.*` (com exceção de `.env.example`) ao `.gitignore`.
- Criei `.env.example` documentando todas as variáveis sem valores reais.

⚠️ **Ação recomendada para você**: se o `.env` **já foi commitado** alguma vez no histórico do Git deste repositório, o ideal é (a) confirmar no GitHub se ele aparece em algum commit antigo e, se sim, (b) considerar essas chaves como potencialmente expostas — como são chaves "publicáveis" do novo formato do Supabase (`sb_publishable_...`), o risco é baixo (elas são desenhadas para serem usadas no client, protegidas pelo RLS), mas o ID do projeto ficando público facilita reconhecimento/targeting. Não é urgente, mas é higiene básica corrigir daqui pra frente.

---

## 3. Proposta de Arquitetura de Pagamento

Não encontrei nenhuma integração de pagamento no código — hoje, a única forma de um aluno ganhar acesso é alguém (você) inserir manualmente uma linha em `enrollments` via `service_role`. Como não sei qual gateway vocês preferem (Stripe, Hotmart, Kiwify, Mercado Pago — bastante comuns para infoprodutos no Brasil), não implementei a integração final (exigiria as credenciais e a decisão do provedor), mas desenho abaixo a arquitetura completa e o esqueleto de código, pronta para plugar o provedor escolhido.

### 3.1 Por que um *webhook* de servidor, e não uma chamada direta do client

O aluno **nunca** deve poder chamar algo do tipo `supabase.from('enrollments').insert(...)` diretamente — isso equivaleria a se autoconceder acesso pago de graça. O fluxo correto é:

```
[Aluno paga no checkout do provedor]
        │
        ▼
[Provedor de pagamento chama um webhook HTTP do seu app]
        │  (assinado/verificado com um segredo do provedor)
        ▼
[Server function valida a assinatura, identifica o e-mail/usuário]
        │
        ▼
[supabaseAdmin (service_role) faz upsert em enrollments]
        │
        ▼
[Aluno já vê o plano ativo na próxima vez que abrir /app]
```

### 3.2 Esqueleto de implementação (genérico, adaptável a qualquer provedor)

```ts
// src/lib/payment-webhook.functions.ts (exemplo — adaptar aos campos do provedor)
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const webhookSchema = z.object({
  email: z.string().email(),
  plan: z.enum(["basico", "intermediario", "mentoria"]),
  provider: z.string(),
  provider_ref: z.string(),
  expires_at: z.string().datetime().nullable().optional(),
});

export const handlePaymentWebhook = createServerFn({ method: "POST" })
  .validator((raw: unknown) => {
    // 1) Verificar assinatura/segredo do provedor ANTES de fazer parse do corpo
    //    (ex.: header Stripe-Signature, ou um token fixo de webhook no query string).
    // 2) Só então validar o schema.
    return webhookSchema.parse(raw);
  })
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Resolve o usuário pelo e-mail (o checkout deve coletar o mesmo e-mail da conta)
    const { data: users } = await supabaseAdmin.auth.admin.listUsers();
    const user = users.users.find((u) => u.email === data.email);
    if (!user) {
      // Guardar o evento para conciliação manual quando o aluno criar a conta depois.
      throw new Error(`Usuário com e-mail ${data.email} ainda não tem conta.`);
    }

    const { error } = await supabaseAdmin.from("enrollments").upsert(
      {
        user_id: user.id,
        plan: data.plan,
        status: "active",
        provider: data.provider,
        provider_ref: data.provider_ref,
        expires_at: data.expires_at ?? null,
      },
      { onConflict: "user_id" },
    );
    if (error) throw new Error(error.message);
    return { ok: true };
  });
```

Pontos que exigem decisão sua antes de eu finalizar isso de verdade:
1. **Qual gateway?** (Stripe é mais simples de verificar assinatura com uma lib oficial; Hotmart/Kiwify têm seus próprios formatos de webhook e a verificação costuma ser por token fixo na URL, não HMAC.)
2. **E se o aluno pagar antes de criar conta na plataforma?** — precisa de uma tabela de "pagamentos pendentes de vínculo" para conciliar quando ele finalmente se cadastrar com aquele e-mail (posso desenhar isso junto).
3. **Cancelamento/reembolso** — o webhook do provedor também dispara eventos de cancelamento; o handler precisa tratar `status: 'canceled'` também, não só a ativação.

Assim que você decidir o provedor, implemento a integração real (validação de assinatura específica, mapeamento de produto→plano, etc.) — é rápido a partir desse esqueleto.

---

## 4. Refatoração e Testes

### 4.1 `components/radiante/Sections.tsx` (688 linhas)

Proposta de divisão (não executei ainda, para não arriscar quebrar algo que já funciona sem eu conseguir rodar `npm run build` para validar):

```
components/radiante/sections/
├── ResultsSection.tsx
├── AboutSection.tsx
├── PlansSection.tsx        (a mais crítica: dados de preço/plano)
├── TestimonialsSection.tsx
├── FaqSection.tsx
├── FinalCta.tsx
└── Footer.tsx
```
Cada arquivo exportando seu componente; `Sections.tsx` viraria um `index.ts` de re-export para não quebrar o import atual em `routes/index.tsx`. Se quiser, faço esse split agora — é mecânico e de baixo risco, mas prefiro seu ok explícito já que você pediu "não faça alterações" anteriormente e eu preciso equilibrar isso com os pedidos de avançar.

### 4.2 Testes — hoje o projeto não tem nenhum

Não existe pasta de testes nem test runner no `package.json`. Sugestão de prioridade (do mais crítico para o menos):

1. **Testes de RLS** (o que mais importa em receita): usar `supabase-js` com dois usuários de teste reais contra um projeto Supabase local (`supabase start`) e afirmar que usuário A nunca lê/escreve dado de usuário B, e que `has_plan_access` bloqueia corretamente por tier.
2. **Testes de hooks** (`use-member.ts`, `use-riot.ts`) com Vitest + `@testing-library/react` mockando o client do Supabase.
3. **Teste de fluxo de auth** (guard de rota redireciona para `/auth` quando não logado).

Setup sugerido (não instalei, pois não há rede neste sandbox):
```bash
npm i -D vitest @testing-library/react @testing-library/jest-dom jsdom
```

Posso montar os arquivos de configuração e os primeiros testes reais assim que você confirmar que quer seguir por aqui — só não quis instalar dependências "no escuro" sem poder rodar `npm install` para confirmar que tudo resolve corretamente neste sandbox.

---

## 5. Resumo do que fazer a seguir (na sua ordem de prioridade sugerida)

1. **Rodar `npm install && npm run build`** localmente/Lovable para validar o código novo (Riot) antes de publicar — não pude fazer isso aqui por falta de rede no sandbox.
2. **Aplicar a nova migration** (`riot_valorant_tracking.sql`) no Supabase.
3. Decidir sobre **gateway de pagamento** para eu finalizar a integração real (§3).
4. Opcional: registrar um app na Riot e configurar `RIOT_API_KEY` para ativar o selo de verificação (não bloqueia nada, é incremental).
5. Confirmar se quer que eu já execute o **refactor do `Sections.tsx`** e/ou monte a **suíte de testes** (§4).
