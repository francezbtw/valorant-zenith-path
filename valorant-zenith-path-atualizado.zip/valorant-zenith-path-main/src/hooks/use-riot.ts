import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { linkRiotAccount, addRankSnapshot } from "@/lib/riot-actions.functions";
import type { RiotRegion } from "@/lib/riot";

export function useRiotAccount() {
  return useQuery({
    queryKey: ["riot-account"],
    queryFn: async () => {
      const { data, error } = await supabase.from("riot_accounts").select("*").maybeSingle();
      if (error) throw error;
      return data;
    },
  });
}

export function useRankHistory() {
  return useQuery({
    queryKey: ["riot-rank-history"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("riot_rank_snapshots")
        .select("*")
        .order("captured_at", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });
}

export function useLinkRiotAccount() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: { gameName: string; tagLine: string; region: RiotRegion }) =>
      linkRiotAccount({ data: input }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["riot-account"] }),
  });
}

export function useAddRankSnapshot() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: {
      rankTier: string;
      rankTierOrder: number;
      rr?: number | null;
      note?: string | null;
    }) => addRankSnapshot({ data: input }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["riot-rank-history"] }),
  });
}
