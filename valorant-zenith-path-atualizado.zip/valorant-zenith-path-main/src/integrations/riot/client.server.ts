// SERVER-ONLY. Nunca importe este arquivo fora de outros módulos `.server.ts`
// ou de server functions — ele lê a variável de ambiente RIOT_API_KEY, que é
// um segredo e jamais deve chegar ao bundle do cliente.
//
// ⚠️ LEIA ANTES DE USAR EM PRODUÇÃO
// A API oficial da Riot para VALORANT (contas, partidas e elo de um jogador
// específico) exige, segundo a documentação atual do Riot Developer Portal,
// uma "Production API Key" aprovada e, para a maioria dos endpoints, o fluxo
// de OAuth "Riot Sign On" (RSO) — a própria Riot afirma hoje não aceitar
// solicitações de chave de nível "pessoal" para esse fluxo. Ou seja: enquanto
// este projeto não tiver uma chave de produção aprovada pela Riot, as
// chamadas abaixo vão falhar (ou nem serão tentadas) e o app cai de forma
// segura no fluxo manual (Tracker.gg + check-in de elo).
//
// Este arquivo existe para:
//   1) já deixar a integração pronta para quando/se a chave for aprovada;
//   2) tentar, best-effort, uma validação simples do Riot ID (Account-V1),
//      que historicamente é menos restrita que os endpoints de elo/partidas.

import { RIOT_ACCOUNT_ROUTING, type RiotRegion } from "@/lib/riot";

const RIOT_API_KEY = process.env.RIOT_API_KEY;

export class RiotApiNotConfiguredError extends Error {
  constructor() {
    super("RIOT_API_KEY não configurada. Verificação automática desativada.");
    this.name = "RiotApiNotConfiguredError";
  }
}

export class RiotApiRequestError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.name = "RiotApiRequestError";
    this.status = status;
  }
}

export function isRiotApiConfigured(): boolean {
  return Boolean(RIOT_API_KEY);
}

type RiotAccountResponse = {
  puuid: string;
  gameName?: string;
  tagLine?: string;
};

/**
 * Resolve um Riot ID (gameName#tagLine) para o PUUID da conta, via
 * Account-V1 (endpoint multi-jogo, roteado por cluster regional).
 * Lança RiotApiNotConfiguredError se não houver chave configurada, e
 * RiotApiRequestError para qualquer resposta não-2xx da Riot (ex.: 404
 * quando o Riot ID não existe, 403 se a chave não tiver escopo suficiente).
 */
export async function resolveRiotAccount(
  gameName: string,
  tagLine: string,
  region: RiotRegion,
): Promise<RiotAccountResponse> {
  if (!RIOT_API_KEY) throw new RiotApiNotConfiguredError();

  const routing = RIOT_ACCOUNT_ROUTING[region];
  const url = `https://${routing}.api.riotgames.com/riot/account/v1/accounts/by-riot-id/${encodeURIComponent(
    gameName,
  )}/${encodeURIComponent(tagLine)}`;

  const response = await fetch(url, {
    headers: { "X-Riot-Token": RIOT_API_KEY },
  });

  if (!response.ok) {
    throw new RiotApiRequestError(
      response.status,
      `Riot Account-V1 respondeu ${response.status} para ${gameName}#${tagLine}`,
    );
  }

  return (await response.json()) as RiotAccountResponse;
}
