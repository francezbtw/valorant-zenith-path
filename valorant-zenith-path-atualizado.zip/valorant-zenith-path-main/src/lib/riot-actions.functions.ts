import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import {
  isRiotApiConfigured,
  resolveRiotAccount,
  RiotApiRequestError,
} from "@/integrations/riot/client.server";
import { isValidRiotTag } from "@/lib/riot";

const linkSchema = z.object({
  gameName: z.string().trim().min(3).max(16),
  tagLine: z.string().trim().min(2).max(5),
  region: z.enum(["br", "na", "eu", "ap", "kr", "latam"]),
});

/**
 * Vincula (ou atualiza) o Riot ID do aluno logado.
 * Sempre grava game_name/tag_line/região informados pelo aluno.
 * Em paralelo, tenta validar via Riot API (best-effort): se houver
 * RIOT_API_KEY configurada e a conta existir, marca verified=true e
 * guarda o puuid; caso contrário, segue sem verificação — o app
 * continua funcional com o fluxo manual (Tracker.gg + check-ins).
 */
export const linkRiotAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((data: unknown) => linkSchema.parse(data))
  .handler(async ({ data, context }) => {
    if (!isValidRiotTag(data.gameName, data.tagLine)) {
      throw new Error("Riot ID inválido. Use o formato Nome#TAG.");
    }

    // client.server.ts (service_role) é necessário aqui porque os campos
    // puuid/verified/last_verified_at/verify_error são bloqueados para o
    // papel `authenticated` por privilégios de coluna (ver migration).
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    let verified = false;
    let puuid: string | null = null;
    let verifyError: string | null = null;

    if (isRiotApiConfigured()) {
      try {
        const account = await resolveRiotAccount(data.gameName, data.tagLine, data.region);
        verified = true;
        puuid = account.puuid;
      } catch (err) {
        verified = false;
        verifyError =
          err instanceof RiotApiRequestError
            ? `Riot API retornou ${err.status}. Confira o Riot ID e a região.`
            : "Não foi possível confirmar a conta na Riot agora.";
      }
    } else {
      verifyError = "Verificação automática indisponível (sem acesso de produção à Riot API).";
    }

    const { data: row, error } = await supabaseAdmin
      .from("riot_accounts")
      .upsert(
        {
          user_id: context.userId,
          riot_game_name: data.gameName,
          riot_tag_line: data.tagLine,
          region: data.region,
          puuid,
          verified,
          last_verified_at: verified ? new Date().toISOString() : null,
          verify_error: verifyError,
        },
        { onConflict: "user_id" },
      )
      .select("*")
      .single();

    if (error) throw new Error(error.message);
    return row;
  });

const snapshotSchema = z.object({
  rankTier: z.string().trim().min(1).max(40),
  rankTierOrder: z.number().int().min(0).max(22),
  rr: z.number().int().min(0).max(100).nullable().optional(),
  note: z.string().trim().max(280).nullable().optional(),
});

/**
 * Registra um check-in manual de elo (linha do tempo de evolução).
 * Usa o client autenticado do próprio usuário (respeita RLS) — não precisa
 * de service_role, pois é dado auto-declarado pelo aluno, como lesson_progress.
 */
export const addRankSnapshot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((data: unknown) => snapshotSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("riot_rank_snapshots").insert({
      user_id: context.userId,
      source: "manual",
      rank_tier: data.rankTier,
      rank_tier_order: data.rankTierOrder,
      rr: data.rr ?? null,
      note: data.note ?? null,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
