// Constantes e helpers puros (seguros para client e server) sobre a
// integração com Valorant. Nenhuma chamada de rede acontece aqui.

export type RiotRegion = "br" | "na" | "eu" | "ap" | "kr" | "latam";

export const RIOT_REGIONS: { value: RiotRegion; label: string }[] = [
  { value: "br", label: "Brasil" },
  { value: "latam", label: "América Latina" },
  { value: "na", label: "América do Norte" },
  { value: "eu", label: "Europa" },
  { value: "ap", label: "Ásia-Pacífico" },
  { value: "kr", label: "Coreia" },
];

// Roteamento "regional" (multi-jogo) usado pela Account-V1 da Riot para
// resolver Riot ID -> PUUID. Cada shard de Valorant mapeia para um cluster.
export const RIOT_ACCOUNT_ROUTING: Record<RiotRegion, "americas" | "europe" | "asia"> = {
  br: "americas",
  latam: "americas",
  na: "americas",
  eu: "europe",
  ap: "asia",
  kr: "asia",
};

export type RankTier = {
  order: number; // 0 = Sem elo, 27 = Radiante
  label: string;
  color: string;
};

// Ordem crescente de elo, em português (como já usado no restante do app).
export const RANK_TIERS: RankTier[] = [
  { order: 0, label: "Sem elo", color: "#6B7280" },
  { order: 1, label: "Ferro 1", color: "#71717A" },
  { order: 2, label: "Ferro 2", color: "#71717A" },
  { order: 3, label: "Ferro 3", color: "#71717A" },
  { order: 4, label: "Bronze 1", color: "#B45309" },
  { order: 5, label: "Bronze 2", color: "#B45309" },
  { order: 6, label: "Bronze 3", color: "#B45309" },
  { order: 7, label: "Prata 1", color: "#94A3B8" },
  { order: 8, label: "Prata 2", color: "#94A3B8" },
  { order: 9, label: "Prata 3", color: "#94A3B8" },
  { order: 10, label: "Ouro 1", color: "#EAB308" },
  { order: 11, label: "Ouro 2", color: "#EAB308" },
  { order: 12, label: "Ouro 3", color: "#EAB308" },
  { order: 13, label: "Platina 1", color: "#22D3EE" },
  { order: 14, label: "Platina 2", color: "#22D3EE" },
  { order: 15, label: "Platina 3", color: "#22D3EE" },
  { order: 16, label: "Ascendente 1", color: "#00F5FF" },
  { order: 17, label: "Ascendente 2", color: "#00F5FF" },
  { order: 18, label: "Ascendente 3", color: "#00F5FF" },
  { order: 19, label: "Imortal 1", color: "#7B2EFF" },
  { order: 20, label: "Imortal 2", color: "#7B2EFF" },
  { order: 21, label: "Imortal 3", color: "#7B2EFF" },
  { order: 22, label: "Radiante", color: "#FDE68A" },
];

export function rankLabelForOrder(order: number): string {
  return RANK_TIERS.find((t) => t.order === order)?.label ?? "Sem elo";
}

export function rankColorForOrder(order: number): string {
  return RANK_TIERS.find((t) => t.order === order)?.color ?? "#6B7280";
}

/**
 * Monta o link público do Tracker.gg para o Riot ID informado.
 * Não depende de nenhuma chave de API — funciona sempre, mesmo sem
 * acesso aprovado à Riot API.
 */
export function buildTrackerUrl(gameName: string, tagLine: string): string {
  const handle = `${gameName}#${tagLine}`;
  return `https://tracker.gg/valorant/profile/riot/${encodeURIComponent(handle)}/overview`;
}

export function isValidRiotTag(gameName: string, tagLine: string): boolean {
  return gameName.trim().length >= 3 && /^[A-Za-z0-9]{2,5}$/.test(tagLine.trim());
}
