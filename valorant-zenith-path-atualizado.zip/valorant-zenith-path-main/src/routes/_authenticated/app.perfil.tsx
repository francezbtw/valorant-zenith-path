import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { Loader2, Save, Link2, ShieldCheck, ShieldAlert, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/membros/MemberShell";
import { supabase } from "@/integrations/supabase/client";
import { useProfile, usePlan } from "@/hooks/use-member";
import { useRiotAccount, useLinkRiotAccount } from "@/hooks/use-riot";
import { PLAN_LABEL } from "@/lib/member";
import { RIOT_REGIONS, buildTrackerUrl, isValidRiotTag, type RiotRegion } from "@/lib/riot";

export const Route = createFileRoute("/_authenticated/app/perfil")({
  head: () => ({
    meta: [
      { title: "Perfil · Área de Membros — Projeto Radiante" },
      { name: "description", content: "Atualize seu nome, Riot ID e elo atual dentro do Projeto Radiante." },
      { property: "og:title", content: "Perfil — Projeto Radiante" },
      { property: "og:description", content: "Seus dados de aluno no Projeto Radiante." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: PerfilPage,
});

function PerfilPage() {
  const { data: profile } = useProfile();
  const plan = usePlan();
  const qc = useQueryClient();
  const [fullName, setFullName] = useState("");
  const [riotId, setRiotId] = useState("");
  const [rank, setRank] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name ?? "");
      setRiotId(profile.riot_id ?? "");
      setRank(profile.current_rank ?? "");
    }
  }, [profile]);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    setSaving(true);
    const { error } = await supabase
      .from("profiles")
      .update({ full_name: fullName, riot_id: riotId, current_rank: rank })
      .eq("id", profile.id);
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    qc.invalidateQueries({ queryKey: ["profile"] });
    toast.success("Perfil atualizado.");
  };

  return (
    <>
      <PageHeader eyebrow={plan ? `Plano ${PLAN_LABEL[plan]}` : "Sem plano"} title="Seu perfil" subtitle="Mantenha seus dados atualizados para as análises da mentoria." />

      <form onSubmit={save} className="max-w-xl space-y-4 rounded-3xl glass-card p-7">
        <Input label="Nome completo" value={fullName} onChange={setFullName} />
        <Input label="Riot ID" value={riotId} onChange={setRiotId} placeholder="Nome#TAG" />
        <Input label="Elo atual" value={rank} onChange={setRank} placeholder="Ex.: Ascendente 2" />
        <div>
          <label className="text-[10px] uppercase tracking-[0.22em] text-white/40">E-mail</label>
          <div className="mt-2 rounded-xl border border-white/8 bg-white/[0.02] px-4 py-3.5 text-sm text-white/45">
            {profile?.email}
          </div>
        </div>
        <button type="submit" disabled={saving} className="btn-hero w-full disabled:opacity-60">
          {saving ? <Loader2 className="h-5 w-5 animate-spin" /> : <Save className="h-5 w-5" />} Salvar alterações
        </button>
      </form>

      <div className="mt-6 max-w-xl">
        <RiotAccountCard />
      </div>
    </>
  );
}

function RiotAccountCard() {
  const { data: account, isLoading } = useRiotAccount();
  const link = useLinkRiotAccount();
  const [gameName, setGameName] = useState("");
  const [tagLine, setTagLine] = useState("");
  const [region, setRegion] = useState<RiotRegion>("br");

  useEffect(() => {
    if (account) {
      setGameName(account.riot_game_name ?? "");
      setTagLine(account.riot_tag_line ?? "");
      setRegion((account.region as RiotRegion) ?? "br");
    }
  }, [account]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValidRiotTag(gameName, tagLine)) {
      toast.error("Riot ID inválido. Use o formato Nome#TAG (ex.: QCK#BR1).");
      return;
    }
    try {
      await link.mutateAsync({ gameName: gameName.trim(), tagLine: tagLine.trim(), region });
      toast.success("Conta Valorant vinculada.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Não foi possível vincular a conta.");
    }
  };

  const trackerUrl = account ? buildTrackerUrl(account.riot_game_name, account.riot_tag_line) : null;

  return (
    <div className="rounded-3xl glass-card p-7">
      <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.24em] text-white/45">
        <Link2 className="h-3.5 w-3.5" /> Conta Valorant
      </div>
      <p className="mt-3 text-sm text-white/55">
        Vincule seu Riot ID para acompanhar sua evolução de elo dentro da plataforma e acessar
        rapidamente seu perfil público no Tracker.gg.
      </p>

      <form onSubmit={submit} className="mt-5 grid gap-3 sm:grid-cols-[2fr_1fr_1fr]">
        <input
          value={gameName}
          onChange={(e) => setGameName(e.target.value)}
          placeholder="Nome (ex.: QCK)"
          className="rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3 text-sm outline-none transition focus:border-[#7B2EFF]/60"
        />
        <input
          value={tagLine}
          onChange={(e) => setTagLine(e.target.value)}
          placeholder="TAG (ex.: BR1)"
          className="rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3 text-sm outline-none transition focus:border-[#7B2EFF]/60"
        />
        <select
          value={region}
          onChange={(e) => setRegion(e.target.value as RiotRegion)}
          className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-3 text-sm outline-none transition focus:border-[#7B2EFF]/60"
        >
          {RIOT_REGIONS.map((r) => (
            <option key={r.value} value={r.value} className="bg-[#0a0a0a]">
              {r.label}
            </option>
          ))}
        </select>
        <button
          type="submit"
          disabled={link.isPending}
          className="btn-hero sm:col-span-3 disabled:opacity-60"
        >
          {link.isPending ? <Loader2 className="h-5 w-5 animate-spin" /> : <Link2 className="h-5 w-5" />}
          {account ? "Atualizar vínculo" : "Vincular conta"}
        </button>
      </form>

      {!isLoading && account && (
        <div className="mt-5 space-y-3 rounded-2xl border border-white/8 bg-white/[0.03] p-4">
          <div className="flex items-center justify-between text-sm">
            <span className="text-white/70">
              {account.riot_game_name}#{account.riot_tag_line}
            </span>
            {account.verified ? (
              <span className="inline-flex items-center gap-1.5 text-xs text-[#00F5FF]">
                <ShieldCheck className="h-3.5 w-3.5" /> Verificada
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 text-xs text-white/45">
                <ShieldAlert className="h-3.5 w-3.5" /> Não verificada
              </span>
            )}
          </div>
          {!account.verified && account.verify_error && (
            <p className="text-xs leading-relaxed text-white/40">{account.verify_error}</p>
          )}
          {trackerUrl && (
            <a
              href={trackerUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 text-xs text-white/60 transition hover:text-[#00F5FF]"
            >
              <ExternalLink className="h-3.5 w-3.5" /> Ver perfil completo no Tracker.gg
            </a>
          )}
        </div>
      )}
    </div>
  );
}

function Input({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <div>
      <label className="text-[10px] uppercase tracking-[0.22em] text-white/40">{label}</label>
      <input
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="mt-2 w-full rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3.5 text-sm outline-none transition focus:border-[#7B2EFF]/60 focus:bg-white/[0.07]"
      />
    </div>
  );
}
