import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { Loader2, TrendingUp } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/membros/MemberShell";
import { useLessons, useModules, useProgress } from "@/hooks/use-member";
import { useAddRankSnapshot, useRankHistory } from "@/hooks/use-riot";
import { PLAN_LABEL } from "@/lib/member";
import { RANK_TIERS, rankColorForOrder } from "@/lib/riot";

export const Route = createFileRoute("/_authenticated/app/progresso")({
  head: () => ({
    meta: [
      { title: "Meu Progresso · Área de Membros — Projeto Radiante" },
      { name: "description", content: "Acompanhe módulo a módulo o quanto você já evoluiu dentro do Projeto Radiante." },
      { property: "og:title", content: "Meu Progresso — Projeto Radiante" },
      { property: "og:description", content: "Seu histórico de aulas concluídas e evolução por módulo." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ProgressoPage,
});

function ProgressoPage() {
  const { data: modules = [] } = useModules();
  const { data: lessons = [] } = useLessons();
  const { data: progress = [] } = useProgress();

  const completed = new Set(progress.filter((p) => p.completed).map((p) => p.lesson_id));
  const total = lessons.length;
  const done = lessons.filter((l) => completed.has(l.id)).length;
  const pct = total ? Math.round((done / total) * 100) : 0;

  return (
    <>
      <PageHeader eyebrow="Histórico real" title="Meu progresso" subtitle="Cada aula concluída é uma decisão a menos tomada no escuro." />

      <div className="rounded-3xl glass-card p-8">
        <div className="flex items-end justify-between">
          <div>
            <div className="text-[10px] uppercase tracking-[0.24em] text-white/45">Conclusão total</div>
            <div className="mt-2 font-display text-5xl font-bold text-gradient-brand">{pct}%</div>
          </div>
          <div className="text-right text-sm text-white/50">{done}/{total} aulas</div>
        </div>
        <div className="mt-6 h-2.5 w-full overflow-hidden rounded-full bg-white/8">
          <motion.div
            initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
            className="h-full rounded-full bg-gradient-to-r from-[#7B2EFF] via-[#00AEEF] to-[#00F5FF] shadow-[0_0_20px_rgba(0,245,255,0.6)]"
          />
        </div>
      </div>

      <div className="mt-5 space-y-4">
        {modules.map((mod, i) => {
          const modLessons = lessons.filter((l) => l.module_id === mod.id);
          const d = modLessons.filter((l) => completed.has(l.id)).length;
          const p = modLessons.length ? Math.round((d / modLessons.length) * 100) : 0;
          return (
            <motion.div
              key={mod.id}
              initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.45, delay: i * 0.05 }}
              className="rounded-2xl glass-card p-5"
            >
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium">{mod.title}</span>
                <span className="text-white/45">{PLAN_LABEL[mod.tier]} · {p}%</span>
              </div>
              <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-white/8">
                <div className="h-full rounded-full bg-gradient-to-r from-[#7B2EFF] to-[#00F5FF]" style={{ width: `${p}%` }} />
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="mt-8">
        <RankEvolutionCard />
      </div>
    </>
  );
}

function RankEvolutionCard() {
  const { data: history = [], isLoading } = useRankHistory();
  const addSnapshot = useAddRankSnapshot();
  const [tierOrder, setTierOrder] = useState(0);
  const [rr, setRr] = useState(0);
  const [note, setNote] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const tier = RANK_TIERS.find((t) => t.order === tierOrder);
    if (!tier) return;
    try {
      await addSnapshot.mutateAsync({
        rankTier: tier.label,
        rankTierOrder: tier.order,
        rr,
        note: note.trim() || null,
      });
      setNote("");
      toast.success("Elo registrado. Continue evoluindo!");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Não foi possível salvar o check-in.");
    }
  };

  const chartData = history.map((h) => ({
    date: new Date(h.captured_at).toLocaleDateString("pt-BR", { day: "2-digit", month: "short" }),
    order: h.rank_tier_order,
    label: h.rank_tier,
  }));

  const latest = history[history.length - 1];

  return (
    <div className="rounded-3xl glass-card p-7">
      <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.24em] text-white/45">
        <TrendingUp className="h-3.5 w-3.5" /> Evolução de elo
      </div>
      <p className="mt-3 text-sm text-white/55">
        Registre seu elo periodicamente para visualizar sua curva de evolução real dentro do
        Projeto Radiante — combine com o seu perfil no Tracker.gg para ver o detalhe das partidas.
      </p>

      {isLoading ? (
        <div className="mt-6 flex justify-center"><Loader2 className="h-5 w-5 animate-spin text-white/40" /></div>
      ) : chartData.length > 1 ? (
        <div className="mt-6 h-56 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ left: -20, right: 10, top: 10, bottom: 0 }}>
              <XAxis dataKey="date" stroke="rgba(255,255,255,0.35)" fontSize={11} tickLine={false} axisLine={false} />
              <YAxis
                domain={[0, 22]}
                stroke="rgba(255,255,255,0.35)"
                fontSize={11}
                tickLine={false}
                axisLine={false}
                width={0}
              />
              <Tooltip
                contentStyle={{ background: "#0a0a0a", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12 }}
                labelStyle={{ color: "rgba(255,255,255,0.6)" }}
                formatter={(_value, _name, item) => [item.payload.label, "Elo"]}
              />
              <Line
                type="monotone"
                dataKey="order"
                stroke="#00F5FF"
                strokeWidth={2.5}
                dot={{ r: 3, fill: "#00F5FF" }}
                activeDot={{ r: 5 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      ) : (
        <p className="mt-6 text-xs text-white/40">
          Registre pelo menos dois check-ins para ver o gráfico de evolução.
        </p>
      )}

      {latest && (
        <div className="mt-2 text-xs text-white/45">
          Último registro:{" "}
          <span className="font-medium" style={{ color: rankColorForOrder(latest.rank_tier_order) }}>
            {latest.rank_tier}
          </span>
          {typeof latest.rr === "number" && <> · {latest.rr} RR</>}
        </div>
      )}

      <form onSubmit={submit} className="mt-6 grid gap-3 border-t border-white/8 pt-6 sm:grid-cols-[2fr_1fr_auto]">
        <select
          value={tierOrder}
          onChange={(e) => setTierOrder(Number(e.target.value))}
          className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-3 text-sm outline-none transition focus:border-[#7B2EFF]/60"
        >
          {RANK_TIERS.map((t) => (
            <option key={t.order} value={t.order} className="bg-[#0a0a0a]">
              {t.label}
            </option>
          ))}
        </select>
        <input
          type="number"
          min={0}
          max={100}
          value={rr}
          onChange={(e) => setRr(Number(e.target.value))}
          placeholder="RR"
          className="rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3 text-sm outline-none transition focus:border-[#7B2EFF]/60"
        />
        <button
          type="submit"
          disabled={addSnapshot.isPending}
          className="btn-hero px-5 disabled:opacity-60"
        >
          {addSnapshot.isPending ? <Loader2 className="h-5 w-5 animate-spin" /> : "Registrar"}
        </button>
        <input
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Observação (opcional)"
          className="rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3 text-sm outline-none transition focus:border-[#7B2EFF]/60 sm:col-span-3"
        />
      </form>
    </div>
  );
}
