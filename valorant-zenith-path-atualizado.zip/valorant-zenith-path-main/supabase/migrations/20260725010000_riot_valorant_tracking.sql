-- =========================================================
-- Integração Riot/Valorant: conta vinculada + evolução de elo
-- =========================================================

-- RIOT ACCOUNTS (Riot ID vinculado pelo aluno)
create table public.riot_accounts (
  user_id uuid primary key references auth.users(id) on delete cascade,
  riot_game_name text not null,
  riot_tag_line text not null,
  region text not null default 'br'
    check (region in ('br','na','eu','ap','kr','latam')),
  puuid text,
  verified boolean not null default false,
  last_verified_at timestamptz,
  verify_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

comment on table public.riot_accounts is
  'Riot ID vinculado por aluno. puuid/verified/last_verified_at/verify_error só podem ser '
  'escritos pelo service_role (via server function), nunca diretamente pelo cliente.';

alter table public.riot_accounts enable row level security;

-- Somente o dono pode ver sua própria conta vinculada
create policy "own riot account select" on public.riot_accounts
  for select to authenticated using (auth.uid() = user_id);

create policy "own riot account insert" on public.riot_accounts
  for insert to authenticated with check (auth.uid() = user_id);

create policy "own riot account update" on public.riot_accounts
  for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "own riot account delete" on public.riot_accounts
  for delete to authenticated using (auth.uid() = user_id);

-- Privilégios em nível de COLUNA: o usuário autenticado só pode
-- inserir/atualizar os campos que ele mesmo informa (Riot ID/tag/região).
-- puuid, verified, last_verified_at e verify_error só via service_role,
-- garantindo que o aluno não possa "forjar" uma verificação de conta.
revoke all on public.riot_accounts from authenticated;
grant select on public.riot_accounts to authenticated;
grant insert (user_id, riot_game_name, riot_tag_line, region) on public.riot_accounts to authenticated;
grant update (riot_game_name, riot_tag_line, region) on public.riot_accounts to authenticated;
grant delete on public.riot_accounts to authenticated;
grant all on public.riot_accounts to service_role;

create trigger riot_accounts_touch
  before update on public.riot_accounts
  for each row execute function public.touch_updated_at();

-- RIOT RANK SNAPSHOTS (linha do tempo de evolução de elo)
create table public.riot_rank_snapshots (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  source text not null default 'manual' check (source in ('manual','riot_api')),
  rank_tier text not null,
  rank_tier_order int not null check (rank_tier_order between 0 and 22),
  rr int check (rr between 0 and 100),
  note text,
  captured_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

comment on table public.riot_rank_snapshots is
  'Linha do tempo de elo do aluno. Hoje alimentada por check-ins manuais (source=manual); '
  'reservado o campo source=riot_api para quando houver sincronização automática via Riot API.';

alter table public.riot_rank_snapshots enable row level security;

create policy "own rank history select" on public.riot_rank_snapshots
  for select to authenticated using (auth.uid() = user_id);

-- Check-in é auto-declarado pelo próprio aluno (como lesson_progress) -
-- não há dado sensível de terceiros em jogo aqui.
create policy "own rank history insert" on public.riot_rank_snapshots
  for insert to authenticated with check (auth.uid() = user_id and source = 'manual');

create policy "own rank history delete" on public.riot_rank_snapshots
  for delete to authenticated using (auth.uid() = user_id);

grant select, insert, delete on public.riot_rank_snapshots to authenticated;
grant all on public.riot_rank_snapshots to service_role;

create index riot_rank_snapshots_user_captured_idx
  on public.riot_rank_snapshots (user_id, captured_at desc);
